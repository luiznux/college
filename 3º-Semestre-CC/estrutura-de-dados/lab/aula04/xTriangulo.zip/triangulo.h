/*
Elaborado por prof. Marcio Feitosa
Sao Paulo, 03/04/2019
*/


#ifndef TRIANGULO_H
#define TRIANGULO_H

template <class T>
	class Triangulo {

		private:
		T lado1;
		T lado2;
		T lado3;
		T pMeio;
		bool valido;

		public:
		Triangulo(T x1, T x2, T x3);
		~Triangulo();
		T area();
		bool isValido();
		Triangulo<T> * operator+(Triangulo<T> & t);


	};

#endif
