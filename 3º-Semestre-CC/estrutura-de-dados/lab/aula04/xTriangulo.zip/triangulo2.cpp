/*
Elaborado por prof. Marcio Feitosa
Sao Paulo, 03/04/2019
*/

#include <math.h>
#include "triangulo2.h"

Triangulo2::Triangulo2(double x1, double x2, double x3) {
	this->pMeio = (x1 + x2 + x3) / 2;
	this->valido = x1 < this->pMeio && x2 < this->pMeio && x3 < this->pMeio;
	this->lado1 = x1;
	this->lado2 = x2;
	this->lado3 = x3;
}


Triangulo2::~Triangulo2() {}


double Triangulo2::area() {
	return sqrt(this->pMeio * (this->pMeio - this->lado1) * (this->pMeio - this->lado2) * (this->pMeio - this->lado3));
}


bool Triangulo2::isValido() {
	return this->valido;
}


Triangulo2 * Triangulo2::operator+(Triangulo2 & t) {
	double a = this->area() + t.area();
	double ladoEquiv = 2 * sqrt(a) / pow(3, (1.0 / 4));
	Triangulo2 * tNovo = new Triangulo2(ladoEquiv, ladoEquiv, ladoEquiv);
	return tNovo;
}
