/*
Elaborado por prof. Marcio Feitosa
Sao Paulo, 03/04/2019
*/



#include <math.h>
#include "triangulo.h"

template <class T> Triangulo<T>::Triangulo(T x1, T x2, T x3) {
	this->pMeio = (x1 + x2 + x3) / 2;
	this->valido = x1 < this->pMeio && x2 < this->pMeio && x3 < this->pMeio;
	this->lado1 = x1;
	this->lado2 = x2;
	this->lado3 = x3;
}

template <class T>
	Triangulo<T>::~Triangulo() {}

template <class T>
	T Triangulo<T>::area() {
	return sqrt(this->pMeio * (this->pMeio - this->lado1) * (this->pMeio - this->lado2) * (this->pMeio - this->lado3));
}

template <class T>
	bool Triangulo<T>::isValido() {
	return this->valido;
}

template <class T>
	Triangulo<T> * Triangulo<T>::operator+(Triangulo<T> & t) {
	T a = this->area() + t.area();
	T ladoEquiv = 2 * sqrt(a) / pow(3, 1 / 4);
	Triangulo<T> * tNovo = new Triangulo<T>(ladoEquiv, ladoEquiv, ladoEquiv);
	return tNovo; 
}
