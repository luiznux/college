/*
Elaborado por prof. Marcio Feitosa
Sao Paulo, 03/04/2019
*/


#ifndef TRIANGULO2_H
#define TRIANGULO2_H


class Triangulo2 {

	private:
	double lado1;
	double lado2;
	double lado3;
	double pMeio;
	bool valido;

	public:
	Triangulo2(double x1, double x2, double x3);
	~Triangulo2();
	double area();
	bool isValido();
	Triangulo2 * operator+(Triangulo2 & t);


};

#endif
