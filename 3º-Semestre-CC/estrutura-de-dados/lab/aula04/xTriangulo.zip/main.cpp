#include <iostream>
#include <stdlib.h>

#include "triangulo.cpp"  //= quando se trata de classe template => include o arquivo cpp
#include "triangulo2.h"

int main() {

	/*
	O programa tem duas partes identicas: uma com classe template (Triangulo)
	e outra com classe normal (Triangulo2). A variavel "templ" sinaliza se
	vai rodar a classe template ou a classe normal.
	*/

	bool templ = false; //= true = roda template; false = roda normal

	int max2 = 10;
	int ult2 = -1;

	/*
	-> se templ==true => vai para o bloco correspondente 'a classe template.
	ATENCAO: a instrucao GOTO quebra a estrutura prevista no paradigma da
	Programacao Estruturada. Nao deve ser utilizada em situacoes normais,
	inclusive nao e' muito bem vista no mercado desenvolvedor profissional.
	Aqui esta' sendo utilizada em carater de teste.
	*/
	if (templ) {
		goto comTemplate;
	}

	//= lados do triangulo
	double la;
	double lb;
	double lc;

	//= vetor de triangulos
	Triangulo2 * tris2[max2];

	for (int i = 0; i < max2; i++) {
		tris2[i] = NULL;
	}

	while(true) {
		system("cls");
		std::cout << "\n=====================================================";
		std::cout << "\n   CALCULO DE AREA DE UM TERRENO POR TRIANGULACAO";
		std::cout << "\n                (sem classe template)";
		std::cout << "\n=====================================================";
		std::cout << "\n0 - sair do programa";
		std::cout << "\n1 - incluir triangulo";
		std::cout << "\n2 - calcular area total (acumulacao na variavel 'area')";
		std::cout << "\n3 - calcular area total (somatoria dos objetos com sobrecarga de operador)";
		std::cout << "\n\nSua opcao: ";
		int opc;
		std::cin >> opc;

		if (opc == 0) {
			break;
		} else if (opc == 1) {

			//=== solicitar entrada dos lados
			std::cout << "\nLado 1: ";
			std::cin >> la;
			std::cout << "\nLado 2: ";
			std::cin >> lb;
			std::cout << "\nLado 3: ";
			std::cin >> lc;
			//---

			//= instanciar o novo triangulo
			Triangulo2 * t = new Triangulo2(la, lb, lc);

			//=== verificar se o novo triangulo e' valido
			if (!t->isValido()) {
				std::cout << "\n\nO triangulo nao e' valido. Verifique as dimensoes dos lados.\n\n";
				system("pause");
				continue;
			}
			//---

			ult2++;
			tris2[ult2] = t;

		}

		else if (opc == 2) {
			double areaTotal = 0;
			for (int i = 0; i <= ult2; i++) {
				Triangulo2 * t = tris2[i];
				areaTotal += tris2[i]->area();
			}
			std::cout << "\n\nAREA TOTAL = " << areaTotal << "\n\n";
			system("pause");
		}


		else if (opc == 3) {
			if (ult2 == -1) {
				std::cout << "nao ha' triangulos\n\n";
				system("pause");
				continue;
			}

			Triangulo2 * tFinal = tris2[0];
			for (int i = 1; i <= ult2; i++) {
				tFinal = * tFinal + * tris2[i];
			}

			std::cout << "\n\n" << tFinal->area() << "\n\n";
			system("pause");

		}

	}


	return 0;

	//==========================================================================
	//==========================================================================
	//==========================================================================

	comTemplate:

	typedef double td;

	int max = 10;
	int ult = -1;

	//= lados do triangulo
	td l1;
	td l2;
	td l3;

	Triangulo<td> * tris[max];

	for (int i = 0; i < max2; i++) {
		tris[i] = NULL;
	}

	while(true) {
		system("cls");
		std::cout << "\n=====================================================";
		std::cout << "\n   CALCULO DE AREA DE UM TERRENO POR TRIANGULACAO";
		std::cout << "\n                (com classe template)";
		std::cout << "\n=====================================================";
		std::cout << "\n0 - sair do programa";
		std::cout << "\n1 - incluir triangulo";
		std::cout << "\n2 - calcular area total (acumulacao na variavel 'area')";
		std::cout << "\n3 - calcular area total (somatoria dos objetos com sobrecarga de operador)";
		std::cout << "\n\nSua opcao: ";
		int opc;
		std::cin >> opc;

		if (opc == 0) {
			break;
		} else if (opc == 1) {

			//=== solicitar entrada dos lados
			std::cout << "\nLado 1: ";
			std::cin >> l1;
			std::cout << "\nLado 2: ";
			std::cin >> l2;
			std::cout << "\nLado 3: ";
			std::cin >> l3;
			//---

			//= instanciar o novo triangulo
			Triangulo<td> * t = new Triangulo<td>(l1, l2, l3);

			//=== verificar se o novo triangulo e' valido
			if (!t->isValido()) {
				std::cout << "\n\nO triangulo nao e' valido. Verifique as dimensoes dos lados.\n\n";
				system("pause");
				continue;
			}
			//---

			ult++;
			tris[ult] = t;

		}

		else if (opc == 2) {
			td areaTotal = 0;
			for (int i = 0; i <= ult; i++) {
				Triangulo<td> * t = tris[i];
				areaTotal += tris[i]->area();
			}
			std::cout << "\n\nAREA TOTAL = " << areaTotal << "\n\n";
			system("pause");
		}


		else if (opc == 3) {
			if (ult == -1) {
				std::cout << "nao ha' triangulos\n\n";
				system("pause");
				continue;
			}

			Triangulo<td> * tFinal = tris[0];
			for (int i = 1; i <= ult; i++) {
				tFinal = * tFinal + * tris[i];
			}

			std::cout << "\n\n" << tFinal->area() << "\n\n";
			system("pause");

		}


	}




	return 0;
}



