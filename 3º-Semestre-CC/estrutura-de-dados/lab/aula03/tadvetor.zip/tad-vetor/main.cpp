#include "tadvetor.h"
#include "tadvetor.cpp"

using namespace std;

int main(){

	Tadvetor tv; //variavel do tipo da classe q criei//

	while(true){
		cout << "\n----------------------------------------------";
		cout << "\n RELEMBRANDO VETORES";
		cout << "\n----------------------------------------------";
		cout << "\n0 - sair.";
		cout << "\n1 - imprimir o vetor.";
		cout << "\n2 - inserir um elemento ( >0 e a posicao no vetor tem que estar livre (=0)";
			cout << "\n3 - excluir um elemento.";
		cout << "\n4 - trocar dois elementos de lugar entre si.";
		cout << "\n5 - localizar o maior e o menor elementos do vetor";
		cout << "\n6 - ordenar os elementos do vetor em ordem crescente";
		cout << "\n7 - ordenar os elementos do vetor em ordem decrescente";
		cout << "\n8 - ordenar os elementos do vetor em um segundo vetor (o metodo cria o novo vetor, copia os dados e retorna o vetor ordenado";
		cout << "\n---------------------";
		cout << "\nQual a sua opcao -> ";

		int opc;
		cin >>opc;

		if  (opc == 0){			
			break;
		} else if (opc == 1){
			tv.imprimir();
			cout << "\n\n";

		} else if (opc == 2){
			//=precisa pedir os dados: posição no vetor (indice) e valor do elemento.
			cout << "Indice de novo elemento; ";
			int idx;
			cin >> idx;
			cout << "Valor do elemento: ";
			int val;
			cin >> val;
			cout << tv.incluir(idx,val) << endl;

		} else if (opc == 3 ) {
			cout << "Indice do elemento a ser removido: ";
			int idx;
			cin >> idx;
			int val = tv.excluir(idx);
	
		} else if (opc == 4 ){
      int indice1, indice2;
      cout<< "Digite o primeiro indice";
      cin>>indice1;
      cout<< "Digite o 2 indice";
      cin>>indice2;
			tv.troca(indice1,indice2);
			tv.imprimir();

		} else if (opc == 5){
			tv.maior_menor();
			tv.imprimir();
			

		} else if (opc == 6){
			cout << tv.ordemCrescente();
                        tv.imprimir();

		} else if (opc == 7){
			cout << tv.ordemDecrescente();
			tv.imprimir();

		} else if (opc == 8){
			cout << tv.novoVetor();
		}	
          }//CHAVE DO WHILE LA DE CIMA 	
				
	cout << "\n-------------------------------------------------";
 	cout << "\n\nObrigado e ate' a proxima vez.\n\n\n";
  	return 0;
}
