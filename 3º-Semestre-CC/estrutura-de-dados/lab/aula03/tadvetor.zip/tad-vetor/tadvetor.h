#ifndef TADVETOR_H
#define TADVETOR_H
#define TAMANHO 5

#include <iostream>
#include <string>

class Tadvetor
{
	private:
		int numeros[TAMANHO];

	public:
		Tadvetor();
		void imprimir();//opc1
		std::string incluir(int indice,int valor);//op2
 		int excluir(int indice);//op3
		int troca(int indice1, int indice2);//opc4
		void maior_menor();//opc5
		std::string ordemCrescente();//opc6
		std::string ordemDecrescente();//opc7
		std::string novoVetor();//opc8
};

#endif
