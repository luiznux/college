#include "tadvetor.h"
using namespace std;

Tadvetor::Tadvetor(){
	
	for (int i = 0; i < TAMANHO; i++){
		numeros[i] = 0;
	}

}


void Tadvetor::imprimir(){
	cout << "\n[ ";
	for (int i=0; i<TAMANHO;i++){
		cout << numeros [i] << " ";
	}
	cout<<"]";
}


std::string Tadvetor::incluir(int indice,int valor){
	if(valor<0){
		return "ERRO: o valor tem que ser maior que zero.";
	}
	
	if(indice<0 || indice > TAMANHO -1){
		return "ERRO: o indice está fora fora dos limites do vetor.";
	}
	
	if(numeros[indice] >0){
		return "ERRO: posição ocupada.";
	}

	numeros[indice] = valor;
	return "Inclusão bem sucedida.";
}

int Tadvetor::excluir(int indice){
	if (indice < 0 || indice > TAMANHO - 1){
		return -1;
	}

	int numero = numeros[indice];

	numeros[indice] = 0;
	return numero;
}

int Tadvetor::troca(int indice1, int indice2){
	if(indice1 < 0 || indice2 < 0){
		return -1;
	}

	if (indice1 < TAMANHO || indice2 < TAMANHO){
		return -1;
	}
	
	int aux;
	aux = numeros[indice2];
	numeros[indice2] = numeros [indice1];
	numeros[indice1] = aux;
	return 0;
}

	
void Tadvetor::maior_menor(){
	int i, maior = numeros[0], menor=numeros[0];
	for (i=0; i < TAMANHO; i++){
		if (numeros[i] > maior){
			maior = numeros[i];
		}
		
		if (numeros[i] < menor){
			menor = numeros[i];
		}
	}
	cout << "Maior valor: "<<maior;
	cout << "\nMenor valor:"<<menor;
}

std::string Tadvetor::ordemCrescente()
{
	 int i, meio;
  	 for (i=0; i < TAMANHO - 1; i++){
    		int menor = i, j;
    		for (j=i+1; j < TAMANHO; j++){
      			if (numeros[menor] > numeros[j])
        			menor = j;
                }
                meio = numeros[menor];
    		numeros[menor] = numeros[i];
    		numeros[i] = meio;
	}

  		return "Vetor ordenado";
}


	
std::string Tadvetor::ordemDecrescente()
{
	int i, meio;
  	for (i=0; i < TAMANHO - 1; i++){
    		int maior = i, j ;
    		for (j=i+1; j < TAMANHO; j++){
      			if (numeros[maior] < numeros[j])
        			maior = j;
    		}    
    		meio = numeros[maior];
    		numeros[maior] = numeros[i];
    		numeros[i] = meio;
  	}
  
  	return "Vetor ordenado decrescente";  
}
		  
	
std::string Tadvetor::novoVetor()
{
	int i , vetor[TAMANHO], meio;
	for (i=0; i < TAMANHO; i++){
    		vetor[i] = numeros[i];
  	}	
  
  	for (i=0; i < TAMANHO - 1; i++){
    		int menor = i, j ;
    		for (j=i+1; j < TAMANHO; j++){
      			if (vetor[menor] > vetor[j])
        			menor = j;
    		}
    		meio = vetor[menor];
    		vetor[menor] = vetor[i];
    		vetor[i] = meio;    
  	}
  	cout << "\n[ ";
  	for (int i = 0; i < TAMANHO; i++) {
    		cout << vetor[i] << " ";
  	}	
  	cout << "]";
  
  	return "\nNovo Vetor ordenado";  
}
	
	
	
