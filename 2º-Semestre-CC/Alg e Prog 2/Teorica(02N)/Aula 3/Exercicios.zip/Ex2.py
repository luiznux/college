def inverteVetor(vet, n):
    vet2 = [0]*n

    for i in range(0, n):
        vet2[i] = vet[n-1-i]

    return vet2

vet = [4, 9, 10, 8, 6]

vetInvertido = inverteVetor(vet, len(vet)) 

for i in range(0,len(vetInvertido)):
    print(vetInvertido[i], end = " ")
