def vetorOrdenado(vet):       
    flag = True
    for i in range(0,len(vet)-1):
        if vet[i] > vet[i+1]:
            flag = False
            break
    return flag

vet = [0]*10

#popular vetor ordenado
for i in range(0,len(vet)):
    vet[i] = i+1

if vetorOrdenado(vet):
    print("vetor em ordem crescente: ")
    for i in range(0, len(vet)):
        print(vet[i], end=" ")
else:
    print("o vetor não está ordenado: ")


