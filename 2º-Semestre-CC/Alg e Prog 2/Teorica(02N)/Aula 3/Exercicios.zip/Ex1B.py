def vetorOrdenado(vet):
    flag = True
    for i in range(0,len(vet)-1):
        if vet[i] > vet[i+1]:            
            flag = False
            break
    return flag
            
    
vetOrd = [0]*10
vetDesord = [0]*10

#popular vetor ordenado
for i in range(0,len(vetOrd)):
    vetOrd[i] = i+1

#popular vetor desordenado
for i in range(0, len(vetDesord)):
    vetDesord[i] = len(vetDesord)-i    

if vetorOrdenado(vetDesord):
    print("vetor em ordem crescente: ")
    for i in range(0, len(vetOrd)):
        print(vetOrd[i], end=" ")
else:
    print("vetor em ordem decrescente: ")
    for i in range(0, len(vetDesord)):
        print(vetDesord[i], end=" ")





