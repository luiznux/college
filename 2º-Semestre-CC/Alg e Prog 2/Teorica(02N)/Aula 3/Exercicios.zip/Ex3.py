def interseccaoVetor(vet1, vet2):
    string = ""
    for i in range(0, len(vet1)):
        for j in range(0, len(vet2)):
            if vet1[i] == vet2[j]:
                string += str(vet1[i]) + ", "
                break;
    return string


vet1 = [7, 2, 5, 8, 4]
vet2 = [4, 2, 9, 5]

print(interseccaoVetor(vet1, vet2))


