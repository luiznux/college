def inverteVetor(vet):
    n = len(vet)
    for i in range(0, int(n/2)):
        aux = vet[i]
        vet[i] = vet[n-1-i]
        vet[n-1-i] = aux
        print(vet[i])
        print(vet[n-1-i])
    return vet

vet = [4, 9, 10, 8, 6]

print(inverteVetor(vet))
    
