import funcoes
def main():

   # testes
   print("0! =", funcoes.fatorial(0))
   print("1! =", funcoes.fatorial(1))
   print("5! =", funcoes.fatorial(5))
   print("17! =", funcoes.fatorial(17))
  
#chama a funcao principal
main()