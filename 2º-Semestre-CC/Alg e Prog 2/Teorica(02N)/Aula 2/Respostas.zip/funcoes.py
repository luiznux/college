def fatorial(n):
   n_fat = 1
   cont = 1
   while cont < n:
      cont += 1       # o mesmo que cont = cont + 1
      n_fat *= cont   # o mesmo que n_fat = k_fat * cont

   return n_fat

def combinacao(m, n):
   return fatorial(m)/(fatorial(n)*fatorial(m-n))

