def leNumero():
    num = int(input("digite um numero:"))
    return num

def mult(a,b):
    s = 0   
    cont = 0
    while cont < b:
        s = s + a
        cont = cont + 1
    return s

def pot(x,y):
    m = 1   
    cont = 0
    while cont < y:
        m *= x
        cont = cont + 1
    return m

#----- MAIN ---- PROGRAMA
var1 = leNumero()
var2 = leNumero()
resp1 = mult(var1,var2)
resp2 = pot(var1,var2)

print("mult=",resp1)
print("pot=",resp2)














