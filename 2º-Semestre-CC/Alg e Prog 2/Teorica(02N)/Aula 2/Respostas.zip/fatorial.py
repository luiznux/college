def fatorial(n):
   n_fat = 1
   cont = 1
   while cont < n:
      cont += 1       # o mesmo que cont = cont + 1
      n_fat *= cont   # o mesmo que n_fat = k_fat * cont

   return n_fat

# testes
print("0! =", fatorial(0))
print("1! =", fatorial(1))
print("5! =", fatorial(5))
print("17! =", fatorial(17))