def leNumero():
    num = int(input("digite um numero:"))
    return num

def ehPrimo( N ):
    div = 2
    while div < N: # repete de 2 ate N - 1
        # se em algum  momento das divisoes
        # der resto 0, N deixa de ser primo
        if N%div == 0:
            return False
        
        div=div+1

    #fim do while
    return True

#----- MAIN ---- PROGRAMA

N1 = leNumero()
N2 = leNumero()
# Imprimir todos os primos entre N1 e N2 (inclusive)
while N1 <= N2:
    #chamo a funcao ehPrimo
    resposta = ehPrimo(N1)
    if resposta == True:
        print(N1)


    N1+=1













