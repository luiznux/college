#ifndef STACK_H
#define STACK_H
#include "node.h"

class Stack{

private:
    int *top_stack;


public:

    Stack();
    ~Stack();
    bool empty();
    bool push(int item);
    bool pop();
    bool top(int &item);
    void print();
};

#endif
