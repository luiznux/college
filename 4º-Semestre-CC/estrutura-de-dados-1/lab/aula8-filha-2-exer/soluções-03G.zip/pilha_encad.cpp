#include <sstream>
#include <iostream>
#include "pilha_encad.h"

using namespace std;


PilhaEncad::~PilhaEncad() {

}

int PilhaEncad::getTamanho() {
	return tamanho;
}

Node * PilhaEncad::getTopo() {
	return topo;
}



bool PilhaEncad::push(int n) {
	Node * no = new Node();
	no->info = n;
	no->proximo = topo;
	topo = no;
	tamanho++;
}

bool PilhaEncad::pop() {
	if (!empty()) {
		Node * no = topo;
		topo = no->proximo;
		delete no;
		tamanho--;
		return true;
	}
	return false;
}

bool PilhaEncad::empty() {
	return topo == NULL;
}

string  PilhaEncad::print() {

	stringstream ss;
	ss << "[ ";

	Node * cursor = topo;
	if (!empty()) {
		while (cursor != NULL) {
			ss << cursor->info << " ";
			cursor = cursor->proximo;
		}
	}
	ss << "]";

	return ss.str();
}

/**
 * Sobrecaraga do operador ==
 * Compara duas pilhas: (1) se tem mesmo tamanho e (2) se os valores dos nohs sao iguais.
 * Este exemplo possibilita que a classe externa tenha acesso ao ponteiro do topo da outra.
 * Caso nao seja possivel, e' necessario criar uma pilha auxiliar para remover
 * um a um os elementos da pilha remota para poder compara-los com os elementos
 * da plilha local para depois retornar os elementos (selecione na variavel
 * "metodo_utilizado" 1 = tem acesso ao topo; 2 = nao tem acesso
 */
bool PilhaEncad::operator==(PilhaEncad & p) {

	int metodo_utilizado = 2;

	if (metodo_utilizado == 1) {

		//= (1)
		if (tamanho != p.getTamanho()) {
			return false;
		}
		//= se as duas estiverem vazias -> consideram-se iguais.
		if (empty() && p.empty()) {
			return true;
		}

		//= (2)
		Node * cursor1 = topo;
		Node * cursor2 = p.getTopo();

		cout << "\n\n";
		while (cursor1 != NULL) {
			cout << "\n" << cursor1->info << " =? " << cursor2->info;
			if (cursor1->info != cursor2->info) {
				return false;
			}
			cursor1 = cursor1->proximo;
			cursor2 = cursor2->proximo;
		}

		return true;


	} else {

		PilhaEncad paux;
		Node * cursor = topo;
		bool iguais = true;

		while (cursor != NULL) {

			if (cursor->info != p.getTopo()->info) {
				iguais = false;
			} else {
				//= pilha externa chegou ao final antes da local (tamanhos diferentes)
				if (p.empty()){
					iguais = false;
					break;
				}
				paux.push(p.pop());
				cursor = cursor->proximo;
			}

			if (!iguais)
				break;

		}
		
		if (!p.empty()) //= pilha local chegou ao final e remota ainda nao -> diferentes
			iguais = false;

		//== restabelecer a pilha remota
		while(!paux.empty()) {
			p.push(paux.pop());
		}

		return iguais;


	}


}
