#include <string.h>
#include <stdlib.h>

using namespace std;

struct Node {
	int info;
	Node * proximo;
	Node(int item = 0, Node * novoend = NULL) {
		info = item;
		proximo = novoend;
	}
};

class PilhaEncad {
	private:
	Node * topo;
	int tamanho; //= prof. Marcio
	public:
	PilhaEncad( ) {
		topo = NULL;
		tamanho = 0;
	}
	~PilhaEncad();
	bool empty( );
	bool push(int);
	bool pop( );
	bool top(int & ) ;
	//==========================================================================
	//= by prof. Marcio
	string print();
	bool operator==(PilhaEncad & p);
	int getTamanho();
	Node * getTopo(); //= implementei este metodo para poder acessar, de outra classe, o topo da pilha.

	//--------------------------------------------------------------------------
};

