
#define TAMANHO 10

#include <iostream>
#include <sstream>

#include "pilha_encad.h"

using namespace std;


void converteDecBin01(int x);


class Fila {
	private:
	int contador;
	int frente, atras;
	int vetorfila[TAMANHO];
	public:
	Fila( );
	bool vazia( ) ;
	int remove( ); //= esse metodo precisa retornar int (o elemento extraido) para ser utilizado na inversao da fila.
	bool insere(int );
	bool consulta(int & );
	//= by prof. Marcio ========================================================
	bool cheia();
	void inverte();
	string imprime();
	bool inverte1();
	bool inverte2();
	//--------------------------------------------------------------------------
};


class Pilha {
	private:
	int vet[TAMANHO];
	int topo;
	public:
	Pilha();
	int pop(); //= idem comentario no metodo "remove" da clase Fila.
	bool push(int);
	bool isEmpty();
	bool top(int & );
	//==========================================================================
	//= by prof. Marcio
	bool isFull();
	string print();

	//--------------------------------------------------------------------------
};



//==============================================================================
//==============================================================================
//           codigo abaixo desenvolvido por prof. Marcio Feitosa
//==============================================================================
//==============================================================================

//==============================================================================
//                            P I L H A (vetor)
//==============================================================================
Pilha::Pilha() {
	topo = -1;
}

bool Pilha::isEmpty() {
	return topo == -1;
}

bool Pilha::isFull() {
	return topo == TAMANHO - 1;
}

int Pilha::pop() {
	if (isEmpty()) {
		return -1;
	} else {
		int aux = vet[topo];
		topo--;
		return aux;
	}

}

bool Pilha::push(int n) {
	if (isFull()) {
		return false;
	} else {
		topo++;
		vet[topo] = n;
		return true;
	}
}

string Pilha::print() {

	stringstream ss;
	ss << "[ ";
	for (int i = 0; i <= topo; i++) {
		ss << vet[i] << " ";
	}
	ss << "]";

	return ss.str();

}

//------------------------------------------------------------------------------


//==============================================================================
//                                  F I L A
//==============================================================================

Fila::Fila() {
	contador = 0;
	frente = -1;
	atras = -1;
}

bool Fila::cheia() {
	return contador == TAMANHO;
}

bool Fila::vazia() {
	return contador == 0;
}

bool Fila::insere(int n) {


	if (!cheia()) {
		if (frente == -1) {
			frente = 0;
		}
		atras = (atras + 1) % TAMANHO;
		vetorfila[atras] = n;
		contador++;
		return true;
	}

	return false;

}

int Fila::remove() {

	int aux;
	if (!vazia()) {
		aux = vetorfila[frente];
		contador--;
		if (vazia()) {
			frente = -1;
			atras = -1;
		} else {
			frente = (frente + 1) % TAMANHO ;
		}
		return aux;

	} else {
		return -1;
	}

}

string Fila::imprime() {

	stringstream ss;
	ss << "[ ";

	if (!vazia()) {
		for (int i = frente; i < TAMANHO; i++) {
			if (frente <= atras && i > atras) {
				break;
			}
			ss << vetorfila[i] << " ";
		}
		if (atras < frente) {
			for (int i = 0; i <= atras; i++) {
				ss << vetorfila[i] << " ";
			}
		}
	}

	ss << "]";

	return ss.str();

}

/**
 * Inverter os elementos de uma fila utilizando uma pilha auxiliar.
 */
bool Fila::inverte1() {

	return true;
}

//==============================================================================
//                               M A I N ( )
//==============================================================================
int main() {

	//=== criar uma fila e inserir 4 elementos
	Fila f1;
	f1.insere(34);
	f1.insere(96);
	f1.insere(2);
	f1.insere(147);

	cout << "\n\nImprimindo a fila...\n";
	cout << f1.imprime();

	//=== criar uma pilha e inserir 4 elementos para teste dos metodos
	Pilha p1;
	p1.push(67);
	p1.push(12);
	p1.push(88);
	p1.push(3);

	cout << "\n\nImprimindo a pilha com os quatro elementos: ";
	cout << "\n" << p1.print();

	//=== retirar um a um os elementos da pilha ate' esvazia-la
	p1.pop();
	cout << "\n" << p1.print() << " depois do primeiro pop()";

	p1.pop();
	cout << "\n" << p1.print() << " depois do segundo pop()";

	p1.pop();
	cout << "\n" << p1.print() << " depois do terceiro pop()";

	p1.pop();
	cout << "\n" << p1.print() << " depois do quarto pop()";

	p1.pop();
	cout << "\n" << p1.print() << " depois do quinto pop()";
	//---

	/**
	 * =========================================================================
	 * Agora vamos inverter a ordem dos elemento da fila. Para isso
	 * utilizaremos uma pilha para passar todos os elemento da fila e depois
	 * retornamos os elementos da pilha para a fila.
	 */
	while (!f1.vazia()) {
		p1.push(f1.remove());
	}

	while (!p1.isEmpty()) {
		f1.insere(p1.pop());
	}

	cout << "\n\nImprimindo a fila invertida...\n";
	cout << f1.imprime();
	//--------------------------------------------------------------------------

	/**
	 * =========================================================================
	 * Agora vamos criar duas pilhas encadeadas e compara-las por sobrecarga
	 * do operador ==
	 */

	PilhaEncad pE1;
	PilhaEncad pE2;

	pE1.push(67);
	pE1.push(12);
	pE1.push(88);
	pE1.push(3);

	pE2.push(67);
	pE2.push(12);
	pE2.push(88);
	pE2.push(3);

	cout << "\n\nPilha 1 => " << pE1.print();
	cout << "\nPilha 2 => " << pE2.print();

	if (pE1 == pE2) {
		cout << "\n\nAs pilhas encadeadas sao iguais.";
	} else {
		cout << "\n\nAs pilhas encadeadas NAO sao iguais.";
	}

	//--------------------------------------------------------------------------

	/**
	 * Finalmente vamos converter um numero de decimal para binario utilizando uma pilha.
	 *
	 */


	//==

	Pilha pDB;

	int numeroDB = 1000; //= se necessario aumente o tamanho maximo da pilha.
	int n = numeroDB;

	do {
		pDB.push(n % 2);
		n /= 2;
	} while (n >= 2);

	cout << "\n\n" << numeroDB << " em binario e' ";
	while (!pDB.isEmpty()) {
		cout << pDB.pop();
	}
	
	//= outra versao
	converteDecBin01(numeroDB);

	//--------------------------------------------------------------------------
	
	
	
	
	

	cout << "\n\n\n------ FIM ------\n\n\n";

	return 0;
}
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------





//==============================================================================
//===== METODOS DOS ALUNOS


void converteDecBin01(int x) {

	Pilha p;
	bool y = true;
	int cont = 0;
	int z = x;
	while (z > 2^cont) {
		cont++;
	}
	while (y) {
		if (z < 2^cont) {
			p.push(0);
			cont--;
		}
		else if (z >= 2^cont) {
			p.push(1);
			z = z - 2^cont;
			if (z <= 0)
				y=false;
			cont--;
		}
	}
	
	cout << "\n\nO numero decimal " << x << " em binario e': ";
	while (!p.isEmpty())
		cout<< p.pop();

}

