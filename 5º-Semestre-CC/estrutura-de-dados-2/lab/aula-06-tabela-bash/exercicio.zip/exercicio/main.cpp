#include "hashtable-linear-probing.cpp"
int main() {
	HashTable ht(13);
	double values[4] = {12, 14.5, 12, 32.7};
	int i;

	for(i = 0; i < 4; i++) {
		ht.insert(values[i]);
	}

}
