class Main{
  public static void main(String[] args) {
    Fracao f1 = new Fracao(2,3);

    System.out.println(f1);
  }
}