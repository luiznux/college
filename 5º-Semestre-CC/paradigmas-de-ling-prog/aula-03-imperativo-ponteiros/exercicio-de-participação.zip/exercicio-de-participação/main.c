#include <stdio.h>
#include "frac.h"


int main(){

    fraction uno, dos;

    printf("Digite seu numerador para a primeira fração: \n ->");
    scanf("%d", &uno.dom);

    printf("Digite seu denomidanor para a primeira fração: \n ->");
    scanf("%d", &uno.dem);

    printf("Digite seu numerador para a segunda fração: \n ->");
    scanf("%d", &dos.dom);

    printf("Digite seu denomidanor para a segunda fração: \n ->");
    scanf("%d", &dos.dem);

    printf("%d/%d",sum(uno,dos).dom, sum(uno,dos).dem);

    return 0;
}
