
typedef struct{ //tipo fração(a/b) contendo dominador(a) e denominador(b)
    int dom; //dominador
    int dem; //denominador
}fraction;


/*
  função para calcular a soma de frações, recebedo como parametros as duas frações
  e retornando a fração resultante
 */
fraction sum(fraction a, fraction b){

    fraction answ;
    answ.dom = (a.dom*b.dem + b.dom*a.dem);
    answ.dem = a.dem*b.dem;
    return answ;
}

/*
  função para calcular a subtração de frações, recebedo como parametros as duas frações
  e retornando a fração resultante
 */
fraction sub(fraction a, fraction b){

    fraction answ;
    answ.dom = (a.dom*b.dem - b.dom*a.dem);
    answ.dem = a.dem*b.dem;
    return answ;
}

/*
  função para calcular a multiplicação de frações, recebedo como parametros as duas frações
  e retornando a fração resultante
 */
fraction mult (fraction a, fraction b){

    fraction answ;
    answ.dom = a.dom*b.dom;
    answ.dem = a.dem*b.dem;
    return answ;
}

/*
  função para calcular a divisao de frações, recebedo como parametros as duas frações
  e retornando a fração resultante
 */

fraction div (fraction a, fraction b){

    fraction answ;
    answ.dom = a.dom*b.dem;
    answ.dem = a.dem*b.dom;
    return answ;
}

/*
  função para verificar se as duas frações sao iguais
*/
int  equal (fraction a, fraction b){

    if(a.dom*b.dem == a.dem*b.dom) return 1;
    return 0;
}

