/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testaponto;

/**
 *
 * @author fabio
 */
public class TestaPonto {

    /**
     * cliente para testar a classe Ponto
     */
    public static void main(String[] args) {
        Ponto p1 = new Ponto(10, 20);
        System.out.println("ponto="+p1);
        
    }
    
}
